現在利用している効果音素材(加工調整含)の配布元です。

魔王魂 様
https://maoudamashii.jokersounds.com/

効果音ラボ 様
https://soundeffect-lab.info/
