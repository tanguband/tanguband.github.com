﻿#pragma once

#include "system/angband.h"

void do_cmd_query_symbol(player_type *creature_ptr);
