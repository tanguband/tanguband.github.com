﻿#pragma once

#include "system/angband.h"

void do_cmd_help(player_type *creature_ptr);
