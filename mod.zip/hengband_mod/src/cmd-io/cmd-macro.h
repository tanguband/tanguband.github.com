﻿#pragma once

#include "system/angband.h"

void do_cmd_macros(player_type *creature_ptr, void (*process_autopick_file_command)(char *));
