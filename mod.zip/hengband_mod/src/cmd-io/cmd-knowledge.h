﻿#pragma once

#include "system/angband.h"

void do_cmd_knowledge(player_type *creature_ptr);
