﻿#pragma once

#include "system/angband.h"

void do_cmd_edit_autopick(player_type *player_ptr);
