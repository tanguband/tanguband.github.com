﻿#pragma once

#include "system/angband.h"

#define MAX_SUBTITLE 33

extern concptr subtitle[MAX_SUBTITLE];
