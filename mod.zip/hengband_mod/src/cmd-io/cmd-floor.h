#pragma once

#include "system/angband.h"

void do_cmd_target(player_type *creature_ptr);
void do_cmd_look(player_type *creature_ptr);
void do_cmd_locate(player_type *creature_ptr);
