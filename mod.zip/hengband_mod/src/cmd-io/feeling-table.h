﻿#pragma once

#include "system/angband.h"

#define MAX_FEELING_TEXT 11

extern concptr do_cmd_feeling_text[MAX_FEELING_TEXT];
extern concptr do_cmd_feeling_text_combat[MAX_FEELING_TEXT];
extern concptr do_cmd_feeling_text_lucky[MAX_FEELING_TEXT];
