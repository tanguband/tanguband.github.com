﻿#pragma once

#include "system/angband.h"

bool cast_learned_spell(player_type *caster_ptr, SPELL_IDX spell, const bool success);
