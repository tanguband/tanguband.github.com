﻿#pragma once

#include "system/angband.h"

bool get_learned_power(player_type *caster_ptr, SPELL_IDX *sn);
