﻿#pragma once

#include "system/angband.h"
#include "monster-attack/monster-attack-util.h"

void process_aura_counterattack(player_type *target_ptr, monap_type *monap_ptr);
