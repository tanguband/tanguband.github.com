#pragma once

#include "system/angband.h"

void do_cmd_equip(player_type *creature_ptr);
void do_cmd_wield(player_type *creature_ptr);
void do_cmd_takeoff(player_type *creature_ptr);
