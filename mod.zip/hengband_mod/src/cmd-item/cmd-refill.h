#pragma once

#include "system/angband.h"

void do_cmd_refill(player_type *user_ptr);
