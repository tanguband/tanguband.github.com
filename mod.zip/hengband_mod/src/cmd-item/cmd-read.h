﻿#pragma once

#include "system/angband.h"

void do_cmd_read_scroll(player_type *creature_ptr);
