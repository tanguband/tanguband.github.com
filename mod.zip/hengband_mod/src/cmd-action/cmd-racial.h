﻿#pragma once

#include "system/angband.h"

void do_cmd_racial_power(player_type *creature_ptr);
