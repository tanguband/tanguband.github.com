﻿#pragma once

#include "system/angband.h"

void do_cmd_fire(player_type *creature_ptr, SPELL_IDX snipe_type);
