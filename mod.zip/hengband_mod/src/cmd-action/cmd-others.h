﻿#pragma once

#include "system/angband.h"

void do_cmd_search(player_type *creature_ptr);
void do_cmd_alter(player_type *creature_ptr);
void do_cmd_suicide(player_type *creature_ptr);
