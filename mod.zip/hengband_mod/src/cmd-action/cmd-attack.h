#pragma once

#include "system/angband.h"
#include "player-attack/player-attack-util.h"

bool do_cmd_attack(player_type *attacker_ptr, POSITION y, POSITION x, combat_options mode);
