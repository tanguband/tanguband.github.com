﻿#pragma once

#include "system/angband.h"

bool do_cmd_mane(player_type *creature_ptr, bool baigaesi);
