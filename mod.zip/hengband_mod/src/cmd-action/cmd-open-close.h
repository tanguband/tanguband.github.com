﻿#pragma once

#include "system/angband.h"

void do_cmd_open(player_type *creature_ptr);
void do_cmd_close(player_type *creature_ptr);
void do_cmd_disarm(player_type *creature_ptr);
void do_cmd_bash(player_type *creature_ptr);
void do_cmd_spike(player_type *creature_ptr);
