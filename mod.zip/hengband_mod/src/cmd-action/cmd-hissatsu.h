﻿#pragma once

#include "system/angband.h"

void do_cmd_hissatsu(player_type *creature_ptr);
void do_cmd_gain_hissatsu(player_type *creature_ptr);
