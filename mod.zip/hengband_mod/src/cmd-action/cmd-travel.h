﻿#pragma once

#include "system/angband.h"

void do_cmd_travel(player_type *creature_ptr);
