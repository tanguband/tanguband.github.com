﻿#pragma once

#include "system/angband.h"

void do_cmd_mind(player_type *caster_ptr);
void do_cmd_mind_browse(player_type *caster_ptr);
void do_cmd_mind_browse(player_type *caster_ptr);

