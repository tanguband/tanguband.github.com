﻿#pragma once

#include "system/angband.h"
#include "effect/effect-player-util.h"

void effect_player_old_heal(player_type *target_ptr, effect_player_type *ep_ptr);
void effect_player_old_speed(player_type *target_ptr, effect_player_type *ep_ptr);
void effect_player_old_slow(player_type *target_ptr);
void effect_player_old_sleep(player_type *target_ptr, effect_player_type *ep_ptr);
