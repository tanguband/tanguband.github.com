﻿#pragma once

#include "system/angband.h"
#include "effect/effect-player-util.h"

void effect_player_curse_1(player_type *target_ptr, effect_player_type *ep_ptr);
void effect_player_curse_2(player_type *target_ptr, effect_player_type *ep_ptr);
void effect_player_curse_3(player_type *target_ptr, effect_player_type *ep_ptr);
void effect_player_curse_4(player_type *target_ptr, effect_player_type *ep_ptr);
