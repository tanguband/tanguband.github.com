﻿#pragma once

#include "system/angband.h"

bool exe_tunnel(player_type *creature_ptr, POSITION y, POSITION x);
