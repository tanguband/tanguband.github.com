﻿#pragma once

#include "system/angband.h"

bool exe_mutation_power(player_type *creature_ptr, int power);
