﻿#pragma once

#include "system/angband.h"

void exe_movement(player_type *creature_ptr, DIRECTION dir, bool do_pickup, bool break_trap);
