﻿#pragma once

#include "system/angband.h"

void verify_equip_slot(player_type *owner_ptr, INVENTORY_IDX item);
