#pragma once

#include "system/angband.h"

void exe_activate(player_type *user_ptr, INVENTORY_IDX item);
