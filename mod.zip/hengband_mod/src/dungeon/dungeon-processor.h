﻿#pragma once

#include "system/angband.h"

void process_dungeon(player_type* player_ptr, bool load_game);
