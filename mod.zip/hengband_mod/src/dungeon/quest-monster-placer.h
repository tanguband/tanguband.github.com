﻿#pragma once

#include "system/angband.h"

bool place_quest_monsters(player_type *creature_ptr);
