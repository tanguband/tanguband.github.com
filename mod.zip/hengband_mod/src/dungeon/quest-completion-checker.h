﻿#pragma once

#include "system/angband.h"

typedef struct monster_type monster_type;
void check_quest_completion(player_type *player_ptr, monster_type *m_ptr);
