#pragma once

#include "system/angband.h"

void compact_objects(player_type *owner_ptr, int size);
