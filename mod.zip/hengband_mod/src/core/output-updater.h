﻿#pragma once

#include "system/angband.h"

void update_output(player_type* player_ptr);
