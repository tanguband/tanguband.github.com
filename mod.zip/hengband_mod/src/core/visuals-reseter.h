﻿#pragma once

#include "system/angband.h"

void reset_visuals(player_type *owner_ptr, void (*process_autopick_file_command)(char *));
