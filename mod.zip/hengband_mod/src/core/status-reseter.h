﻿#pragma once

#include "system/angband.h"

void reset_tim_flags(player_type *creature_ptr);
