﻿#pragma once

#include "system/angband.h"

void disturb(player_type *creature_ptr, bool stop_search, bool flush_output);
