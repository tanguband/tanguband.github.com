﻿#pragma once

#include "system/angband.h"

void play_game(player_type* player_ptr, bool new_game, bool browsing_movie);
