﻿#pragma once

#include "system/angband.h"

void process_player_hp_mp(player_type* creature_ptr);
bool hp_player(player_type *creature_ptr, int num);
