﻿#pragma once

#include "system/angband.h"

void close_game(player_type* player_ptr);
