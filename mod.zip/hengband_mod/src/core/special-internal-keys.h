﻿#pragma once

/*
 * Special internal key
 */
#define SPECIAL_KEY_QUEST 255
#define SPECIAL_KEY_BUILDING 254
#define SPECIAL_KEY_STORE 253
#define SPECIAL_KEY_QUIT 252
