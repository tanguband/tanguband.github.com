﻿#pragma once

#include "system/angband.h"

void reduce_magic_effects_timeout(player_type* creature_ptr);
