﻿#pragma once

#include "system/angband.h"

bool get_player_realms(player_type* creature_ptr);
