﻿#pragma once

#include "system/angband.h"

void get_height_weight(player_type *creature_ptr);
void get_ahw(player_type *creature_ptr);
void get_money(player_type *creature_ptr);
