﻿#pragma once

#include "system/angband.h"

void edit_history(player_type *creature_ptr, void (*process_autopick_file_command)(char *));
