﻿#pragma once

#include "system/angband.h"

bool player_birth_wizard(player_type *creature_ptr, void (*process_autopick_file_command)(char *));
