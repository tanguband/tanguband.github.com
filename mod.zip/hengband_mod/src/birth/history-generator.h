﻿#pragma once

#include "system/angband.h"

void get_history(player_type* creature_ptr);
