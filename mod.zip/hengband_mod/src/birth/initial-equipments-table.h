﻿#pragma once

#include "system/angband.h"

extern byte player_init[MAX_CLASS][3][2];
