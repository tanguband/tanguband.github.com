﻿#pragma once

#include "system/angband.h"

void player_birth(player_type *creature_ptr, void(*process_autopick_file_command)(char*));
