﻿#pragma once

#include "system/angband.h"

void player_wipe_without_name(player_type *creature_ptr);
void init_dungeon_quests(player_type *creature_ptr);
void init_turn(player_type *creature_ptr);
