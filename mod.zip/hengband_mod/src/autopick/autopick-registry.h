﻿#pragma once

#include "system/angband.h"
#include "autopick/autopick-util.h"
#include "system/object-type-definition.h"

bool autopick_autoregister(player_type *player_ptr, object_type *o_ptr);
