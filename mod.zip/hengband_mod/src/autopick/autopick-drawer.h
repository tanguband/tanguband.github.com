﻿#pragma once

#include "system/angband.h"
#include "autopick/autopick-util.h"

void draw_text_editor(player_type *player_ptr, text_body_type *tb);
