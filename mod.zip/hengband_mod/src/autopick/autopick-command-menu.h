﻿#pragma once

int do_command_menu(int level, int start);
