﻿#pragma once

void process_autopick_file_command(char *buf);
