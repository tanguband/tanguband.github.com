﻿#pragma once

#include "system/angband.h"

void auto_destroy_item(player_type *player_ptr, object_type *o_ptr, int autopick_idx);
