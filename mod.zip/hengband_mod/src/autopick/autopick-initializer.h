﻿#pragma once

void init_autopick(void);
