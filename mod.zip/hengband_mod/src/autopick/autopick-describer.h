﻿#pragma once

#include "autopick/autopick-util.h"

void describe_autopick(char *buff, autopick_type *entry);
