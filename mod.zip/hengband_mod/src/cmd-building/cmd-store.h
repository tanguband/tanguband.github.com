﻿#pragma once

#include "system/angband.h"

void do_cmd_store(player_type *player_ptr);
