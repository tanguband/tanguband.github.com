﻿#pragma once

#include "system/angband.h"

bool inn_comm(player_type *customer_ptr, int cmd);
