﻿#pragma once

#include "system/angband.h"

typedef struct object_type object_type;
void random_plus(object_type *o_ptr);
