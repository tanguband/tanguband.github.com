﻿#pragma once

#include "system/angband.h"

void give_activation_power(object_type *o_ptr);
