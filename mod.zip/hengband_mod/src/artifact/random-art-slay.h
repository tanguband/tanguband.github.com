﻿#pragma once

#include "system/angband.h"

void random_slay(object_type *o_ptr);
