﻿#pragma once

#include "system/angband.h"

void random_resistance(object_type *o_ptr);
