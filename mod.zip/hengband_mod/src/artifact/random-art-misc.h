﻿#pragma once

#include "system/angband.h"

void random_misc(player_type *player_ptr, object_type *o_ptr);
