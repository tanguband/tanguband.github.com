h_scores.raw を scores.raw に名前を変更すれば、
某所のスコアファイルが使用できます。
