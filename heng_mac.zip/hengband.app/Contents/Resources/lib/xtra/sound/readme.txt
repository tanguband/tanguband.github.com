現在利用している効果音素材(加工調整含)の配布元です。

CC0効果音:
https://opengameart.org/content/50-rpg-sound-effects

https://opengameart.org/content/rpg-sound-pack

https://opengameart.org/content/80-cc0-rpg-sfx

https://opengameart.org/content/teleport-spell

https://opengameart.org/content/door-open-door-close

https://opengameart.org/content/37-hitspunches

https://opengameart.org/content/sci-fi-vehicle-sound

https://opengameart.org/content/ghost

https://opengameart.org/content/apple-bite

https://opengameart.org/content/7-eating-crunches

https://opengameart.org/content/75-cc0-breaking-falling-hit-sfx

https://opengameart.org/content/metal-clang-explosions-zing

https://opengameart.org/content/sand-spell

https://opengameart.org/content/3-dark-magic-spells

https://opengameart.org/content/swishes-sound-pack

https://opengameart.org/content/flight-or-spell-sound

https://opengameart.org/content/heartbeat-single-sound

https://opengameart.org/content/gui-sound-effects

https://opengameart.org/content/insect-or-alien-scream

https://opengameart.org/content/2-dice-roll-29-throws