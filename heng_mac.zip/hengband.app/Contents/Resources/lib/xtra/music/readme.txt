現在利用しているBGM素材(加工調整含)の配布元です。

CC BY 4.0
https://creativecommons.org/licenses/by/4.0/

CC BY 3.0
https://creativecommons.org/licenses/by/3.0/

CC 0
https://creativecommons.org/publicdomain/zero/1.0/


-----------------------------------------------------------------------
Determined Pursuit：
https://opengameart.org/content/determined-pursuit-epic-orchestra-loop
QaziJamJam：
https://opengameart.org/content/qazijamjam-orchestral-battle-theme
-----------------------------------------------------------------------
The above Music by "Emma_MA" is licensed underCC 0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Leap Into Eternity (Live Orchestra)：
https://opengameart.org/content/leap-into-eternity-live-orchestra
Woodland Fantasy：
https://opengameart.org/content/woodland-fantasy
Wasteland Overdrive：
https://opengameart.org/content/wasteland-overdrive
Blackmoor Tides (Epic Pirate Battle Theme)：
https://opengameart.org/content/blackmoor-tides-epic-pirate-battle-theme
Dark Descent - Extended Cut：
https://opengameart.org/content/dark-descent-extended-cut
Wasteland Showdown [Battle Music]：
https://opengameart.org/content/wasteland-showdown-battle-music
Evasion：
http://opengameart.org/content/evasion
Heroic Demise [Updated Version]：
https://opengameart.org/content/heroic-demise-updated-version
The Dark Amulet - Dark Mage Theme：
https://opengameart.org/content/the-dark-amulet-dark-mage-theme
-----------------------------------------------------------------------
The above Music by "Matthew Pablo(www.matthewpablo.com)" is licensed underCC BY 3.0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Treasure Hunter：
https://opengameart.org/content/treasure-hunter
-----------------------------------------------------------------------
The above Music by "TAD(https://www.youtube.com/c/Tadon)" is licensed underCC 0
modified by "Sasahito Handa"
-----------------------------------------------------------------------
Forward Operating Base：
https://opengameart.org/content/forward-operating-base
"Arcana" by Tadctrl preview：
https://opengameart.org/content/arcana-by-tadctrl-preview
Revenge：
https://opengameart.org/content/revenge
Wind Run：
https://opengameart.org/content/wind-run
-----------------------------------------------------------------------
The above Music by "TAD(https://www.youtube.com/c/Tadon)" is licensed underCC BY 4.0
modified by "Sasahito Handa"
-----------------------------------------------------------------------
Epic Orchestra+Drum music：
https://opengameart.org/content/epic-orchestradrum-music
-----------------------------------------------------------------------
The above Music by "TAD(https://www.youtube.com/c/Tadon)" is licensed underCC BY 3.0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Boss Introduction - Orchestra：
https://opengameart.org/content/boss-introduction-orchestra
Search - Cinematic：
https://opengameart.org/content/search-cinematic
Hero on Guard - Orchestra：
https://opengameart.org/content/hero-on-guard-orchestra
Mist Forest - Orchestra：
https://opengameart.org/content/mist-forest-orchestra
Field - Orchestra：
https://opengameart.org/content/field-orchestra
Panic - Orchestra：
https://opengameart.org/content/panic-orchestra
Despair：
https://opengameart.org/content/despair
Somewhere - Emotional Orchestra：
https://opengameart.org/content/somewhere-emotional-orchestra
-----------------------------------------------------------------------
The above Music by "migfus20" is licensed underCC BY 4.0 
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Mutant Orchestra：
https://opengameart.org/content/mutant-orchestra
-----------------------------------------------------------------------
The above Music by "joeBaxterWebb" is licensed underCC BY 4.0 
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Menu or Level Select Theme：
https://opengameart.org/content/menu-or-level-select-theme
-----------------------------------------------------------------------
The above Music by "Axton Dylan Crolley" is licensed underCC BY 3.0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Epic Departure：
https://opengameart.org/content/epic-departure
Throne Room：
https://opengameart.org/content/throne-room
-----------------------------------------------------------------------
The above Music by "Of Far Different Nature" is licensed underCC BY 4.0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Fantasy - Grasslands：
https://opengameart.org/content/fantasy-grasslands
-----------------------------------------------------------------------
The above Music by "Doge" is licensed underCC 0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Fantasy Music - The Elven Groves：
https://opengameart.org/content/fantasy-music-the-elven-groves
Fantasy Music - The Mourning Forest：
https://opengameart.org/content/fantasy-music-the-mourning-forest
Fantasy Music - The Wraiths of Winter：
https://opengameart.org/content/fantasy-music-the-wraiths-of-winter
Through the Veil Of Time - Collab with TAD：
https://opengameart.org/content/through-the-veil-of-time-collab-with-tad
Fantasy Music - Alandriel's Theme：
https://opengameart.org/content/fantasy-music-alandriels-theme
-----------------------------------------------------------------------
The above Music by "HitCtrl" is licensed underCC BY 3.0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Dungeon of Agony：
https://opengameart.org/content/dungeon-of-agony
-----------------------------------------------------------------------
The above Music by "Gundatsch(https://soundcloud.com/gundatsch)" is licensed underCC BY 3.0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Dungeon Theme 1：
https://opengameart.org/content/dungeon-theme-1
-----------------------------------------------------------------------
The above Music by "LarsG" is licensed underCC BY 4.0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Fantasy Music - Night Town：
https://opengameart.org/content/fantasy-music-night-town
-----------------------------------------------------------------------
The above Music by "Angus Macnaughton 2014" is licensed underCC BY 4.0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Fantasy: Lament for a Warrior's Soul：
https://opengameart.org/content/fantasy-lament-for-a-warriors-soul
-----------------------------------------------------------------------
The above Music by "RandomMind" is licensed underCC 0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Sleep Talking / Loop / Fantasy / RPG / Sci-Fi：
https://opengameart.org/content/sleep-talking-loop-fantasy-rpg-sci-fi
-----------------------------------------------------------------------
The above Music by "KiluaBoy" is licensed underCC 0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Our Mountain_v003：
https://opengameart.org/content/our-mountainv003
-----------------------------------------------------------------------
This work is licensed under a Creative Commons Attribution 4.0 International License. 
Our Mountain_v003 by "Eric Matyas" - Soundimage.org


-----------------------------------------------------------------------
Harp Theme ~ Destroyed Sanctuary：
https://opengameart.org/content/harp-theme-destroyed-sanctuary
-----------------------------------------------------------------------
The above Music by "Art of Escapism" is licensed underCC BY 3.0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
A Small Fire Will Do (Calming Loop)
https://opengameart.org/content/a-small-fire-will-do-calming-loop
-----------------------------------------------------------------------
The above Music by "Trex0n" is licensed underCC BY 0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Elven Shrine：
https://opengameart.org/content/elven-shrine
-----------------------------------------------------------------------
The above Music by "lazugna" is licensed underCC BY 4.0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Riser #42 - Medieval / Witcher：
https://opengameart.org/content/riser-42-medieval-witcher
-----------------------------------------------------------------------
The above Music by "Music by Tri-Tachyon - https://soundcloud.com/tri-tachyon/albums"." is licensed underCC BY 3.0
modified by "Sasahito Handa"


-----------------------------------------------------------------------
Dark Clouds Covering The Horizon：
https://opengameart.org/content/dark-clouds-covering-the-horizon-loading-background-music
-----------------------------------------------------------------------
The above Music by "Francisco Javier González López from Black Light Sound" is licensed underCC BY 3.0
modified by "Sasahito Handa"